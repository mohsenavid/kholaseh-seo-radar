document.getElementById("scan-btn").addEventListener("click", async () => {
  const statusSpan = document.getElementById("status");
  const resultsDiv = document.getElementById("results");
  
  statusSpan.innerText = "در حال تحلیل...";
  statusSpan.style.color = "#ff9800";
  resultsDiv.style.display = "none";
  resultsDiv.innerHTML = "";

  try {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // جلوگیری از گیر کردن روی صفحات تنظیمات خود کروم
    if (!tab.url || tab.url.startsWith("chrome://") || tab.url.startsWith("chrome-extension://")) {
      statusSpan.innerText = "روی این صفحه کار نمی‌کند!";
      statusSpan.style.color = "#f44336";
      return;
    }

    // تزریق کد به سایت
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: scanEEATSignals,
    }, (injectionResults) => {
      if (chrome.runtime.lastError) {
        statusSpan.innerText = "خطا در دسترسی به سایت!";
        statusSpan.style.color = "#f44336";
        return;
      }
      
      if (injectionResults && injectionResults[0] && injectionResults[0].result) {
        displayResults(injectionResults[0].result);
      } else {
        statusSpan.innerText = "خطا در دریافت اطلاعات!";
        statusSpan.style.color = "#f44336";
      }
    });
  } catch (error) {
    statusSpan.innerText = "خطای سیستمی!";
    statusSpan.style.color = "#f44336";
  }
});

// این تابع مستقیم میره تو کدهای سایتی که بازه می‌گرده
function scanEEATSignals() {
  let hasAuthor = false;
  let hasOrg = false;
  let hasDate = false;
  let schemaCount = 0;

  try {
    // گشتن دنبال کدهای JSON-LD (اسکیما)
    const schemas = document.querySelectorAll('script[type="application/ld+json"]');
    schemaCount = schemas.length;

    schemas.forEach(script => {
      try {
        const jsonString = script.innerText.toLowerCase();
        
        // بررسی نوع اسکیماها با جستجوی متنی ساده برای جلوگیری از خطا
        if (jsonString.includes('"@type":"person"') || jsonString.includes('"@type": "person"') || jsonString.includes('author')) {
          hasAuthor = true;
        }
        if (jsonString.includes('"@type":"organization"') || jsonString.includes('"@type": "organization"')) {
          hasOrg = true;
        }
        if (jsonString.includes('datepublished') || jsonString.includes('datemodified')) {
          hasDate = true;
        }
      } catch (e) {
        // رد کردن خطا
      }
    });

    // گشتن دنبال لینک شبکه‌های اجتماعی (سیگنال اعتماد)
    const links = document.querySelectorAll('a[href*="linkedin.com"], a[href*="twitter.com"], a[href*="instagram.com"]');
    const hasSocialLinks = links.length > 0;

    return { schemaCount, hasAuthor, hasOrg, hasDate, hasSocialLinks };
  } catch (error) {
    return { schemaCount: 0, hasAuthor: false, hasOrg: false, hasDate: false, hasSocialLinks: false, error: true };
  }
}

// این تابع نتایج رو تو افزونه نمایش میده
function displayResults(data) {
  const statusSpan = document.getElementById("status");
  const resultsDiv = document.getElementById("results");
  
  if (data.error) {
    statusSpan.innerText = "خطا در پردازش اسکیما";
    statusSpan.style.color = "#f44336";
    return;
  }

  let score = 0;
  let html = "<ul style='text-align: right; padding-right: 20px; font-size: 13px; line-height: 1.8; color: #ddd; direction: rtl;'>";

  if (data.schemaCount > 0) { html += "<li>✅ کدهای اسکیما یافت شد (" + data.schemaCount + " مورد)</li>"; score += 20; }
  else { html += "<li>❌ صفحه فاقد هرگونه اسکیما است</li>"; }

  if (data.hasAuthor) { html += "<li>✅ اسکیمای نویسنده/شخص (Author)</li>"; score += 30; }
  else { html += "<li>❌ فاقد اسکیمای نویسنده (ضعف E-E-A-T)</li>"; }

  if (data.hasOrg) { html += "<li>✅ اسکیمای سازمان/برند (Organization)</li>"; score += 20; }
  else { html += "<li>❌ فاقد اسکیمای سازمان</li>"; }

  if (data.hasDate) { html += "<li>✅ تاریخ انتشار/آپدیت مشخص است</li>"; score += 15; }
  else { html += "<li>❌ فاقد تاریخ ساختاریافته</li>"; }

  if (data.hasSocialLinks) { html += "<li>✅ لینک شبکه‌های اجتماعی یافت شد</li>"; score += 15; }
  else { html += "<li>❌ فاقد لینک سوشیال (اعتبار پایین)</li>"; }

  html += "</ul>";

  // تعیین رنگ نمره
  let color = score >= 80 ? "#4CAF50" : (score >= 50 ? "#ff9800" : "#f44336");
  
  statusSpan.innerText = "اسکن کامل شد";
  statusSpan.style.color = "#4CAF50";
  
  resultsDiv.style.display = "block";
  resultsDiv.innerHTML = `<div style="font-size: 22px; font-weight: bold; color: ${color}; text-align: center; margin-bottom: 10px;">امتیاز E-E-A-T: ${score}/100</div>${html}`;
}